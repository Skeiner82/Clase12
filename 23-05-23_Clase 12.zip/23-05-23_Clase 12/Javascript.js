function saludo() {
  let nombre = prompt("Ingresa tu nombre, por favor");

  if (nombre) {
    alert("¡Bienvenido, " + nombre + "!");
  } else {
    alert("Por favor, ingresa tu nombre.");
  }
}












